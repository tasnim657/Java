import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student {
    private int studentId;
    private String studentName;
    private double studentCGPA;

    public Student(int studentId, String studentName, double studentCGPA) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentCGPA = studentCGPA;
    }

    public int getStudentId(){
        return studentId;
    }

    @Override
    public String toString() {
        return "Student ID: " + studentId + ", Name: " + studentName + ", CGPA: " + studentCGPA;
    }
}

class Course {
    private String courseId;
    private String courseTitle;
    private double credit;
    private Student[] studentArray;
    private int numberOfStudents;
    private Faculty faculty;

    public Course(String courseId, String courseTitle, double credit) {
        this.courseId = courseId;
        this.courseTitle = courseTitle;
        this.credit = credit;
        this.studentArray = new Student[100];
        this.numberOfStudents = 0;
    }

    @Override
    public String toString() {
        return "Course ID: " + courseId + ", Title: " + courseTitle + ", Credit: " + credit;
    }

    public void addStudent(Student student) {
        if (numberOfStudents < studentArray.length) {
            studentArray[numberOfStudents] = student;
            numberOfStudents++;
        } else {
            System.out.println("Maximum number of students reached for this course.");
        }
    }

    public void dropStudent(int studentId) {
        for (int i = 0; i < numberOfStudents; i++) {
            if (studentArray[i].getStudentId() == studentId) {
                studentArray[i] = studentArray[numberOfStudents - 1];
                studentArray[numberOfStudents - 1] = null;
                numberOfStudents--;
                System.out.println("Student dropped from the course.");
                return;
            }
        }
        System.out.println("Student not found in the course.");
    }

    public void addFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public void dropFaculty() {
        this.faculty = null;
    }

    public void printStudentList() {
        System.out.println("Students enrolled in " + courseTitle + ":");
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println(studentArray[i]);
        }
    }
}

class Faculty {
    private int facultyId;
    private String facultyName;
    private String facultyPosition;

    public Faculty(int facultyId, String facultyName, String facultyPosition) {
        this.facultyId = facultyId;
        this.facultyName = facultyName;
        this.facultyPosition = facultyPosition;
    }

    @Override
    public String toString() {
        return "Faculty ID: " + facultyId + ", Name: " + facultyName + ", Position: " + facultyPosition;
    }
}

public class Main {
    private static List<Student> studentList = new ArrayList<>();
    private static List<Course> courseList = new ArrayList<>();
    private static List<Faculty> facultyList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nMenu Options:");
            System.out.println("1. Add");
            System.out.println("2. Delete");
            System.out.println("3. Update");
            System.out.println("4. Print");
            System.out.println("5. Search");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    displayAddMenu();
                    break;

                case 2:
                    displayDeleteMenu();
                    break;

                case 3:
                    displayUpdateMenu();
                    break;

                case 4:
                    displayPrintMenu();
                    break;

                case 5:
                    displaySearchMenu();
                    break;

                case 6:
                    System.out.println("Exiting the application...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void displayAddMenu() {
        System.out.println("\nAdd Options:");
        System.out.println("a. Add a Student");
        System.out.println("b. Add a Course");
        System.out.println("c. Add a Faculty");
    }

    private static void displayDeleteMenu() {
        System.out.println("\nDelete Options:");
        System.out.println("a. Delete a Student");
        System.out.println("b. Delete a Course");
        System.out.println("c. Delete a Faculty");
    }

    private static void displayUpdateMenu() {
        System.out.println("\nUpdate Options:");
        System.out.println("a. Update a Student");
        System.out.println("b. Update a Course");
        System.out.println("c. Update a Faculty");
    }

    private static void displayPrintMenu() {
        System.out.println("\nPrint Options:");
        System.out.println("a. Print all students");
        System.out.println("b. Print all courses");
        System.out.println("c. Print all faculties");
        System.out.println("d. Print information of a student");
        System.out.println("e. Print information of a course");
        System.out.println("f. Print information of a faculty");
        System.out.println("g. Print student list and faculty information of a course");
        System.out.println("h. Print courses taken by a student");
    }

    private static void displaySearchMenu() {
        System.out.println("\nSearch Options:");
        System.out.println("a. Search a Student");
        System.out.println("b. Search a Course");
        System.out.println("c. Search a Faculty");
        System.out.println("d. Search whether a student takes a course");
        System.out.println("e. Search whether a faculty teaches a course");
        System.out.println("f. Search courses taken by a student");
        System.out.println("g. Search courses taught by a faculty");
    }
}
