package SDN0604_assignment;

import java.util.ArrayList;

public class Student {
    int studentId;
    String studentName;
    double studentCGPA;
    Student(){
        System.out.println("Without parameter");
    }

    public Student(int studentId, String studentName, double studentCGPA) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentCGPA = studentCGPA;
    }

    public String toString(){
        return "Student Name: "+studentName +"Student ID: "+studentId+" Student CGPA: "+studentCGPA;


    }

}