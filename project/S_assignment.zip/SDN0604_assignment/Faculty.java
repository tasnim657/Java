package SDN0604_assignment;

public class Faculty {
    int FacultyId;
    String facultyName;
    String facultyPosition;

    public Faculty(int facultyId, String facultyName, String facultyPosition) {
        FacultyId = facultyId;
        this.facultyName = facultyName;
        this.facultyPosition = facultyPosition;
    }

    public Faculty() {
        System.out.println("Without parameter");
    }
    public String toString(){
        return "Faculty Name: "+facultyName+"FacultyId: "+FacultyId+"Faculty position: "+facultyPosition;
    }
}

