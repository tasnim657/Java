package SDN0604_assignment;

import java.util.Arrays;

public class Course {
    String CourseId;
    String courseTitle;
    double credit;
    int numberOfStudents = 100;
    Student[] StudentList;
    Faculty[] faculty;
    static int x = 0;
    static int facultyCount = 0;

    public Course() {
        System.out.println("Without parameter");
    }

    public Course(String courseId, String courseTitle, double credit) {
        CourseId = courseId;
        this.courseTitle = courseTitle;
        this.credit = credit;
    }

    @Override
    public String toString() {
        return "\nCourseId= " + CourseId + '\n' +
                "courseTitle= " + courseTitle + '\n' +
                "credit= " + credit;
    }

    public void addStudent(Student a) {
        StudentList[x++] = new Student(a.studentId, a.studentName, a.studentCGPA);

    }
}
